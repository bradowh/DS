package Exc10_ClasseSealed;



final class ContaCorrente extends Conta {

}