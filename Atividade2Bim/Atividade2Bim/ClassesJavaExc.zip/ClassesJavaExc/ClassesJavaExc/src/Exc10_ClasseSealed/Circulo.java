package Exc10_ClasseSealed;

final class Circulo extends Forma {

}
