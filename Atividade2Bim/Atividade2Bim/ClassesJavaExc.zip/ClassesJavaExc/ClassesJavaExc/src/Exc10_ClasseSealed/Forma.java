package Exc10_ClasseSealed;

public sealed class Forma permits Circulo, Quadrado {

}