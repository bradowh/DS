package Exc10_ClasseSealed;

final class Cliente extends UsuarioSistema {

}
