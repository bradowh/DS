package Exc10_ClasseSealed;

public sealed class Dispositivo permits Notebook, Tablet {

}
