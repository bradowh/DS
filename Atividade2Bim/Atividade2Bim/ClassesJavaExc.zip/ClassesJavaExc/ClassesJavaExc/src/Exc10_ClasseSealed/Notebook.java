package Exc10_ClasseSealed;

final class Notebook extends Dispositivo {

}
