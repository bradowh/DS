package Exc10_ClasseSealed;

final class Tablet extends Dispositivo {

}
