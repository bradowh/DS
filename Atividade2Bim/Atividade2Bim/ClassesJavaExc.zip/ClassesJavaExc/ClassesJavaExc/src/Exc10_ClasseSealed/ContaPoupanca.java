package Exc10_ClasseSealed;



final class ContaPoupanca extends Conta {

}