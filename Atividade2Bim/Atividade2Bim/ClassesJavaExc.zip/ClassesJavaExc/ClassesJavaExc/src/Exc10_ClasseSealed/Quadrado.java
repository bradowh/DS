package Exc10_ClasseSealed;

final class Quadrado extends Forma {

}