package Exc10_ClasseSealed;

final class Video extends Midia {

}