package Exc10_ClasseSealed;

final class LivroDigital extends Midia {

}
