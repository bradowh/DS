package Exc10_ClasseSealed;



public sealed class Conta permits ContaCorrente, ContaPoupanca {

}