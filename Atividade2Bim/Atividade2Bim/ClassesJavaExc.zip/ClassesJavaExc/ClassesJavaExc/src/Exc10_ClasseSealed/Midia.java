package Exc10_ClasseSealed;

public sealed class Midia permits LivroDigital, Video {

}
