package Exc10_ClasseSealed;

public sealed class UsuarioSistema permits Administrador, Cliente {

}
