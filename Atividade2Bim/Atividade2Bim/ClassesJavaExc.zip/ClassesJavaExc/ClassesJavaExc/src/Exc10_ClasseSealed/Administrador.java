package Exc10_ClasseSealed;

final class Administrador extends UsuarioSistema {

}