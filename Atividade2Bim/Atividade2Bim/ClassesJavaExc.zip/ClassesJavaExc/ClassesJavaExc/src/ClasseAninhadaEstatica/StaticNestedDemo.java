package ClasseAninhadaEstatica;


class Empresa {
    // Classe aninhada estática: não depende de instância da classe
    static class Departamento {
        private String nome;

        public Departamento(String nome) {
            this.nome = nome;
        }

        public void mostrar() {
            System.out.println("Departamento: " + nome);
        }
    }
}

public class StaticNestedDemo {
    public static void main(String[] args) {
        // A classe aninhada estática pode ser criada sem objeto externo.
        Empresa.Departamento d = new Empresa.Departamento("Financeiro");
        d.mostrar();
    }
}