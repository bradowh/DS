package Exc5_ClasseAaninhadaEstatica;

public class Aplicativo {

    static class Versao {

        void mostrarVersao() {
            System.out.println("Versão 2.0");
        }
    }

    public static void main(String[] args) {
        Versao versao = new Versao();

        versao.mostrarVersao();
    }
}