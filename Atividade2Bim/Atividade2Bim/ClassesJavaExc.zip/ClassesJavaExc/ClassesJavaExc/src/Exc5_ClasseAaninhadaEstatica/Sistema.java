package Exc5_ClasseAaninhadaEstatica;

public class Sistema {

    static class Log {

        void registrar() {
            System.out.println("Log registrado");
        }
    }

    public static void main(String[] args) {
        Log log = new Log();

        log.registrar();
    }
}