package Exc5_ClasseAaninhadaEstatica;

public class EmpresaTI {

    static class Setor {

        void mostrarSetor() {
            System.out.println("Setor de Desenvolvimento");
        }
    }

    public static void main(String[] args) {
        Setor setor = new Setor();

        setor.mostrarSetor();
    }
}
