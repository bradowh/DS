package Exc5_ClasseAaninhadaEstatica;

public class Universidade {

    static class Curso {

        void mostrarCurso() {
            System.out.println("Curso de ADS");
        }
    }

    public static void main(String[] args) {
        Curso curso = new Curso();

        curso.mostrarCurso();
    }
}
