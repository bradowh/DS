package Exc5_ClasseAaninhadaEstatica;

public class Biblioteca {

    static class Categoria {

        void mostrarCategoria() {
            System.out.println("Categoria Romance");
        }
    }

    public static void main(String[] args) {
        Categoria categoria = new Categoria();

        categoria.mostrarCategoria();
    }
}
