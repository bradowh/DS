package ClasseAnonima;

interface Saudacao {
    void mostrarMensagem();
}

public class AnonimaDemo {
    public static void main(String[] args) {
        // Classe anônima implementando a interface Saudacao.
        Saudacao s = new Saudacao() {
            @Override
            public void mostrarMensagem() {
                System.out.println("Olá! Esta mensagem vem de uma classe anônima.");
            }
        };

        // Chamando o método da classe anônima.
        s.mostrarMensagem();
    }
}