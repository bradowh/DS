package Exc3_ClasseFinal;

import java.time.LocalTime;

final class RelogioSistema {

    void mostrarHora() {
        System.out.println(LocalTime.now());
    }

    public static void main(String[] args) {
        RelogioSistema r = new RelogioSistema();
        r.mostrarHora();
    }
}
