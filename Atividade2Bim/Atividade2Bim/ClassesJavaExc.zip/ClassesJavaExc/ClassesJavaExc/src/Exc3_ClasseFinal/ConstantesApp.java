package Exc3_ClasseFinal;

final class ConstantesApp {

    void mostrarNomeSistema() {
        System.out.println("Sistema Escolar");
    }

    public static void main(String[] args) {
        ConstantesApp app = new ConstantesApp();
        app.mostrarNomeSistema();
    }
}
