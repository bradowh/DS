package Exc3_ClasseFinal;

final class ConfiguracaoSistema {

    void mostrarVersao() {
        System.out.println("Versão 1.0");
    }

    public static void main(String[] args) {
        ConfiguracaoSistema config = new ConfiguracaoSistema();
        config.mostrarVersao();
    }
}