package Exc3_ClasseFinal;

final class ValidadorCPF {

    boolean validar(String cpf) {
        return cpf.length() == 11;
    }

    public static void main(String[] args) {
        ValidadorCPF v = new ValidadorCPF();

        System.out.println(v.validar("12345678901"));
    }
}
