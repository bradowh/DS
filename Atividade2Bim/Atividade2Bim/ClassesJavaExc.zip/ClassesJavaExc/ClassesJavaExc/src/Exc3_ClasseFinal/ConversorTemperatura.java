package Exc3_ClasseFinal;

final class ConversorTemperatura {

    double celsiusParaFahrenheit(double celsius) {
        return (celsius * 9/5) + 32;
    }

    public static void main(String[] args) {
        ConversorTemperatura c = new ConversorTemperatura();

        System.out.println(c.celsiusParaFahrenheit(30));
    }
}