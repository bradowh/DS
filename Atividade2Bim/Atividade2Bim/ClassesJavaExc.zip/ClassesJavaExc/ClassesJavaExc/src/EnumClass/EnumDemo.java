package EnumClass;

// Enum class: conjunto fixo de constantes.
enum StatusPedido {
    PENDENTE,
    PROCESSANDO,
    ENVIADO,
    ENTREGUE
}

public class EnumDemo {
    public static void main(String[] args) {
        // Variável do tipo enum.
        StatusPedido status = StatusPedido.PROCESSANDO;

        // Exibindo o valor escolhido.
        System.out.println("Status atual: " + status);
    }
}