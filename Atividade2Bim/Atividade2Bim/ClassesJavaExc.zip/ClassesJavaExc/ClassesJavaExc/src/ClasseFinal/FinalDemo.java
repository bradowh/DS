package ClasseFinal;

// Arquivo: FinalDemo.java

// Classe final: não pode ser estendida.
final class UtilitarioMatematica {
    // Método simples de soma.
    public int somar(int a, int b) {
        return a + b;
    }
}

public class FinalDemo {
    public static void main(String[] args) {
        // Criando objeto normalmente.
        UtilitarioMatematica u = new UtilitarioMatematica();
        System.out.println("Soma: " + u.somar(10, 5));
    }
}