package Exc4_ClasseInterna;

public class Casa {

    class Quarto {

        void mostrar() {
            System.out.println("Quarto da casa");
        }
    }

    public static void main(String[] args) {
        Casa casa = new Casa();

        Casa.Quarto quarto = casa.new Quarto();

        quarto.mostrar();
    }
}
