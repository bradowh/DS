package Exc4_ClasseInterna;

public class Banco {

    class Agencia {

        void mostrarAgencia() {
            System.out.println("Agência Central");
        }
    }

    public static void main(String[] args) {
        Banco banco = new Banco();

        Banco.Agencia agencia = banco.new Agencia();

        agencia.mostrarAgencia();
    }
}