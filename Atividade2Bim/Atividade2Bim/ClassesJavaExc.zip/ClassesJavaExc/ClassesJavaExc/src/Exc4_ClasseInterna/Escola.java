package Exc4_ClasseInterna;

public class Escola {

    class Turma {

        void mostrarTurma() {
            System.out.println("Turma do 2º ano");
        }
    }

    public static void main(String[] args) {
        Escola escola = new Escola();

        Escola.Turma turma = escola.new Turma();

        turma.mostrarTurma();
    }
}