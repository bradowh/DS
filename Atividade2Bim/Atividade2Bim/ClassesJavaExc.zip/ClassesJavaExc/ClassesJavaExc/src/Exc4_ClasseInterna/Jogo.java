package Exc4_ClasseInterna;

public class Jogo {

    class Jogador {

        void jogar() {
            System.out.println("Jogador iniciou a partida");
        }
    }

    public static void main(String[] args) {
        Jogo jogo = new Jogo();

        Jogo.Jogador jogador = jogo.new Jogador();

        jogador.jogar();
    }
}
