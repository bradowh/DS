package Exc4_ClasseInterna;

public class Loja {

    class Caixa {

        void abrirCaixa() {
            System.out.println("Caixa aberto");
        }
    }

    public static void main(String[] args) {
        Loja loja = new Loja();

        Loja.Caixa caixa = loja.new Caixa();

        caixa.abrirCaixa();
    }
}
