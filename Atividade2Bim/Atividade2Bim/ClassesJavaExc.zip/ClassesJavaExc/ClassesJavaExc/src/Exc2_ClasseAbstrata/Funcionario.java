package Exc2_ClasseAbstrata;

abstract class Funcionario {

    abstract double calcularBonus();
}

class Gerente extends Funcionario {

    @Override
    double calcularBonus() {
        return 1000;
    }

    public static void main(String[] args) {
        Gerente g = new Gerente();

        System.out.println("Bônus: " + g.calcularBonus());
    }
}
