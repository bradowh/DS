package Exc2_ClasseAbstrata;

abstract class FiguraGeometrica {

    abstract double calcularArea();
}

class Quadrado extends FiguraGeometrica {

    double lado = 5;

    @Override
    double calcularArea() {
        return lado * lado;
    }

    public static void main(String[] args) {
        Quadrado q = new Quadrado();

        System.out.println("Área: " + q.calcularArea());
    }
}