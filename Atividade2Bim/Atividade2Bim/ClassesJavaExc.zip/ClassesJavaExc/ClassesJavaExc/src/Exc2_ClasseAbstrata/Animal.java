package Exc2_ClasseAbstrata;

abstract class Animal {

    abstract void emitirSom();
}

class Cachorro extends Animal {

    @Override
    void emitirSom() {
        System.out.println("Au Au");
    }

    public static void main(String[] args) {
        Cachorro cachorro = new Cachorro();
        cachorro.emitirSom();
    }
}