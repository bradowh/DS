package Exc2_ClasseAbstrata;

abstract class Pagamento {

    abstract void processar();
}

class Cartao extends Pagamento {

    @Override
    void processar() {
        System.out.println("Pagamento processado");
    }

    public static void main(String[] args) {
        Cartao c = new Cartao();
        c.processar();
    }
}