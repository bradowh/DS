package Exc2_ClasseAbstrata;

abstract class Transporte {

    abstract void mover();
}

class Carro extends Transporte {

    @Override
    void mover() {
        System.out.println("O carro está se movendo");
    }

    public static void main(String[] args) {
        Carro c = new Carro();
        c.mover();
    }
}