package Exc7_ClasseAnonima;

interface Alarme {

    void tocar();
}

public class AlarmeAnonimo {

    public static void main(String[] args) {

        Alarme a = new Alarme() {

            @Override
            public void tocar() {
                System.out.println("Alarme ativado");
            }
        };

        a.tocar();
    }
}