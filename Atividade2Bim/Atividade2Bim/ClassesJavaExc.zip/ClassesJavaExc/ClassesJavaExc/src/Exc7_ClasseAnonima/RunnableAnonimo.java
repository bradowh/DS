package Exc7_ClasseAnonima;

public class RunnableAnonimo {

    public static void main(String[] args) {

        Runnable r = new Runnable() {

            @Override
            public void run() {
                System.out.println("Thread executada");
            }
        };

        r.run();
    }
}