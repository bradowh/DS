package Exc7_ClasseAnonima;

interface Operacao {

    int somar(int a, int b);
}

public class OperacaoAnonima {

    public static void main(String[] args) {

        Operacao op = new Operacao() {

            @Override
            public int somar(int a, int b) {
                return a + b;
            }
        };

        System.out.println("Resultado: " + op.somar(5, 7));
    }
}