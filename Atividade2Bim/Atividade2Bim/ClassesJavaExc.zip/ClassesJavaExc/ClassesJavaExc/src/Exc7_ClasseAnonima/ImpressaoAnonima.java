package Exc7_ClasseAnonima;

interface Impressao {

    void imprimir();
}

public class ImpressaoAnonima {

    public static void main(String[] args) {

        Impressao imp = new Impressao() {

            @Override
            public void imprimir() {
                System.out.println("Impressão realizada");
            }
        };

        imp.imprimir();
    }
}