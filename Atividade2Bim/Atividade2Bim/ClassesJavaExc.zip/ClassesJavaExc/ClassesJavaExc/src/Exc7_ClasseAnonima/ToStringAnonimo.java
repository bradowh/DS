package Exc7_ClasseAnonima;

public class ToStringAnonimo {

    public static void main(String[] args) {

        Object obj = new Object() {

            @Override
            public String toString() {
                return "Objeto anônimo";
            }
        };

        System.out.println(obj);
    }
}