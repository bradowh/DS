package Exc8_EnumClass;

public enum MesAno {

    JANEIRO,
    FEVEREIRO,
    MARCO;

    public static void main(String[] args) {
        MesAno mesAtual = MesAno.JANEIRO;

        System.out.println("Mês atual: " + mesAtual);

        System.out.println("\nTodos os meses:");
        for (MesAno mes : MesAno.values()) {
            System.out.println(mes);
        }
    }
}