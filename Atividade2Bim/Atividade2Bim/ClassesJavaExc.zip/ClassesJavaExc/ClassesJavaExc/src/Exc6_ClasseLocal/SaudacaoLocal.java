package Exc6_ClasseLocal;

public class SaudacaoLocal {

    void saudar() {

        class Saudacao {

            void mostrar() {
                System.out.println("Bem-vindo!");
            }
        }

        Saudacao s = new Saudacao();

        s.mostrar();
    }

    public static void main(String[] args) {
        SaudacaoLocal saudacao = new SaudacaoLocal();

        saudacao.saudar();
    }
}