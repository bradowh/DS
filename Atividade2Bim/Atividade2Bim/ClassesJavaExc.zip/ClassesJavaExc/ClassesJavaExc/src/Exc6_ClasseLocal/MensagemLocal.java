package Exc6_ClasseLocal;

public class MensagemLocal {

    void exibirMensagem() {

        class Mensagem {

            void mostrar() {
                System.out.println("Olá, mundo!");
            }
        }

        Mensagem mensagem = new Mensagem();
        mensagem.mostrar();
    }

    public static void main(String[] args) {
        MensagemLocal m = new MensagemLocal();

        m.exibirMensagem();
    }
}
