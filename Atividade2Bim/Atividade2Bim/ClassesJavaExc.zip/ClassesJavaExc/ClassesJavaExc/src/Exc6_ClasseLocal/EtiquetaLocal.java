package Exc6_ClasseLocal;

public class EtiquetaLocal {

    void criarEtiqueta() {

        class Etiqueta {

            void mostrarTitulo() {
                System.out.println("Produto em promoção");
            }
        }

        Etiqueta e = new Etiqueta();

        e.mostrarTitulo();
    }

    public static void main(String[] args) {
        EtiquetaLocal etiqueta = new EtiquetaLocal();

        etiqueta.criarEtiqueta();
    }
}
