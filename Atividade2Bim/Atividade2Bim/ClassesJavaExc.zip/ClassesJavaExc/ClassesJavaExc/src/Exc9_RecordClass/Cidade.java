package Exc9_RecordClass;

public record Cidade(String nome, String estado) {
    public static void main(String[] args) {
        Cidade cidade = new Cidade("São Paulo", "SP");
        System.out.println(cidade.nome());
        System.out.println(cidade.estado());
    }
}