package Exc9_RecordClass;

public record Filme(String titulo, int ano) {
    public static void main(String[] args) {
        Filme filme = new Filme("Vingadores", 2012);
        System.out.println(filme.titulo());
        System.out.println(filme.ano());
    }
}
