package Exc9_RecordClass;

public record Usuario(String login, String email) {
    public static void main(String[] args) {
        Usuario usuario = new Usuario("victor", "victor@email.com");
        System.out.println(usuario.login());
        System.out.println(usuario.email());
    }
}