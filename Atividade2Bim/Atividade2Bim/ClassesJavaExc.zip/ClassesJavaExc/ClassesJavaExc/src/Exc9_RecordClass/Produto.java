package Exc9_RecordClass;

public record Produto(String nome, double preco) {
    public static void main(String[] args) {
        Produto produto = new Produto("Mouse", 120.0);
        System.out.println(produto.nome());
        System.out.println(produto.preco());
    }
}