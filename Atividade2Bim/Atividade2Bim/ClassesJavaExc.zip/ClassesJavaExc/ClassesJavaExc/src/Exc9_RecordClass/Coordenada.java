package Exc9_RecordClass;

public record Coordenada(int x, int y) {
    public static void main(String[] args) {
        Coordenada coordenada = new Coordenada(10, 20);
        System.out.println(coordenada.x());
        System.out.println(coordenada.y());
    }
}
