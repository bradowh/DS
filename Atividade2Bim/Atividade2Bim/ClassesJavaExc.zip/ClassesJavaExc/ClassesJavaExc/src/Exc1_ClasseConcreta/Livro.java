package Exc1_ClasseConcreta;

class Livro {
    String titulo;
    String autor;

    public Livro(String titulo, String autor) {
        this.titulo = titulo;
        this.autor = autor;
    }

    public void mostrarDados() {
        System.out.println("Título: " + titulo);
        System.out.println("Autor: " + autor);
    }

    public static void main(String[] args) {
        Livro livro = new Livro("Dom Casmurro", "Machado de Assis");

        livro.mostrarDados();
    }
}