package Exc1_ClasseConcreta;

class Aluno {

    String nome;
    double nota;

    public Aluno(String nome, double nota) {

        this.nome = nome;
        this.nota = nota;
    }

    public void mostrarResultado() {

        if (nota >= 6) {
            System.out.println(nome + " aprovado(a)");
        } else {
            System.out.println(nome + " reprovado(a)");
        }
    }

    public static void main(String[] args) {

        Aluno aluno1 = new Aluno("Maria", 8.5);
        Aluno aluno2 = new Aluno("João", 5.0);

        aluno1.mostrarResultado();
        aluno2.mostrarResultado();
    }
}