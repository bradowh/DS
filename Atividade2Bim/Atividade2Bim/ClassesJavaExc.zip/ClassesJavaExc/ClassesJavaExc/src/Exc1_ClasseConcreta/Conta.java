package Exc1_ClasseConcreta;

class Conta {
    int numero;
    double saldo;

    public Conta(int numero, double saldo) {
        this.numero = numero;
        this.saldo = saldo;
    }

    public void depositar(double valor) {
        saldo += valor;
        System.out.println("Novo saldo: R$ " + saldo);
    }

    public static void main(String[] args) {
        Conta conta = new Conta(1234, 1000.00);

        System.out.println("Saldo inicial: R$ " + conta.saldo);

        conta.depositar(500.00);
    }
}