package Exc1_ClasseConcreta;

class Produto {
    String nome;
    double preco;

    public Produto(String nome, double preco) {
        this.nome = nome;
        this.preco = preco;
    }

    public void exibirPreco() {
        System.out.println(nome + " custa R$ " + preco);
    }

    public static void main(String[] args) {
        Produto produto = new Produto("Notebook", 3500.00);

        produto.exibirPreco();
    }
}