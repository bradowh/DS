package Exc1_ClasseConcreta;

public class Carro {
    String marca;
    String modelo;

    public Carro(String marca, String modelo) {
        this.marca = marca;
        this.modelo = modelo;
    }

    public void exibir() {
        System.out.println(marca + " - " + modelo);
    }

    public static void main(String[] args) {
        Carro carro = new Carro("Toyota", "Corolla");
        carro.exibir();
    }
}